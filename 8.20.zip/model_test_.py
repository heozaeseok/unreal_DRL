# === ppo_eval_realtime.py ===
# 목적: UE 상태를 받아 DI-engine PPO 체크포인트로 아군 2명의 행동을 생성/전송하여
#       학습이 잘 되었는지 간단히 확인 (함수 없이 절차형으로 구성)

import os, numpy as np, torch
from easydict import EasyDict
from ding.model import VAC
from ding.policy import PPOPolicy
from multi_agent_env import SocketMultiAgentEnv

# ===================== 사용자 입력 =====================
MODEL_PATH = r"C:\Users\CIL\Desktop\DI-engine-main\unreal\learned_models\ppo_model_step300000_20250820_091538.pth"
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
NUM_EPISODES = 10
GREEDY = False       # True: eval_mode(greedy), False: collect_mode(stochastic)
PRINT_STEP = True

# ===================== 환경 초기화 =====================
env = SocketMultiAgentEnv({
    'map_size': 7000,
    'max_step': 1000,
    'win_reward': 50,
    'num_detectable': 4,
    'num_agents': 2,
})
agent_ids = env.agent_ids
obs_dim = env.observation_space[agent_ids[0]].shape[0]
act_dim = env.action_space[agent_ids[0]].n

# ===================== 학습 때와 동일한 PPO config =====================
cfg = EasyDict(dict(
    type='ppo',
    action_space='discrete',
    cuda=(DEVICE.type == 'cuda'),
    multi_gpu=False,
    on_policy=True,
    priority=False,
    priority_IS_weight=False,
    multi_agent=True,
    recompute_adv=True,
    transition_with_policy_data=True,
    nstep_return=False,
    model=dict(
        obs_shape=obs_dim,
        action_shape=act_dim,
        encoder_hidden_size_list=[128, 128, 64],
        actor_head_hidden_size=64,
        actor_head_layer_num=2,
        critic_head_hidden_size=64,
        critic_head_layer_num=2,
        share_encoder=True,
        action_space='discrete',
        activation=torch.nn.ReLU(),
        norm_type='LN',
    ),
    learn=dict(
        epoch_per_collect=4,
        batch_size=512,
        learning_rate=3e-4,
        lr_scheduler={'type': 'cosine', 'epoch_num': 2000, 'min_lr': 1e-5, 'min_lr_lambda': 0.1},
        value_weight=0.5,
        entropy_weight=0.01,
        clip_ratio=0.15,
        adv_norm=True,
        value_norm=True,
        ppo_param_init=True,
        grad_clip_type='clip_norm',
        grad_clip_value=1.0,
        ignore_done=False,
    ),
    collect=dict(
        unroll_len=1,
        discount_factor=0.99,
        gae_lambda=0.97,
    ),
    other=dict(
        eps=dict(type='exp', start=1.0, end=0.05, decay=5000)
    ),
))

# ===================== 모델/정책 로드 =====================
model = VAC(**cfg.model).to(DEVICE)
policy = PPOPolicy(cfg, model=model)
if DEVICE.type == 'cuda':
    policy._learn_model.cuda(); policy._collect_model.cuda(); policy._eval_model.cuda()

state = torch.load(MODEL_PATH, map_location=DEVICE)
if 'learn_model' in state:
    policy._learn_model.load_state_dict(state['learn_model'])
    policy._collect_model.load_state_dict(state.get('collect_model', state['learn_model']))
    policy._eval_model.load_state_dict(state.get('eval_model', state['learn_model']))
elif 'model' in state:
    policy._learn_model.load_state_dict(state['model'])
    policy._collect_model.load_state_dict(state['model'])
    policy._eval_model.load_state_dict(state['model'])
else:
    raise RuntimeError(f"Unknown checkpoint keys: {list(state.keys())}")
policy._learn_model.eval(); policy._collect_model.eval(); policy._eval_model.eval()
print(f"[LOAD] checkpoint: {MODEL_PATH}")

# ===================== 평가 루프 (함수 없이) =====================
episode_idx = 0
while episode_idx < NUM_EPISODES:
    print(f"\n=== [EPISODE {episode_idx+1}] ===")
    ts = env.reset()                                           # {'AgentCharacter': obs, 'AgentCharacter2': obs}
    obs_tensor = {aid: torch.tensor(ts[aid], dtype=torch.float32).unsqueeze(0).to(DEVICE)
                  for aid in agent_ids}
    done_all = False
    step = 0
    ep_ret = {aid: 0.0 for aid in agent_ids}

    while not done_all and step < env.max_step:
        with torch.no_grad():
            # 학습 코드와 동일하게 "에이전트별 dict 입력" 사용:contentReference[oaicite:4]{index=4}
            try:
                out = policy.eval_mode.forward(obs_tensor) if GREEDY else policy.collect_mode.forward(obs_tensor)
            except Exception:
                # 일부 버전 호환: collect로 폴백
                out = policy.collect_mode.forward(obs_tensor)

        # out는 보통 {aid: {'action','logit','value'}} 구조:contentReference[oaicite:5]{index=5}
        actions = {}
        probs = {}
        for aid in agent_ids:
            if isinstance(out, dict) and aid in out:
                if 'action' in out[aid]:
                    actions[aid] = out[aid]['action']             # shape (1,)
                elif 'logit' in out[aid]:
                    # 로짓만 있을 경우 argmax로 행동 생성
                    a = torch.argmax(out[aid]['logit'], dim=-1, keepdim=False).to(DEVICE)
                    actions[aid] = a.view(1)                      # shape (1,)
                else:
                    actions[aid] = torch.tensor([0], device=DEVICE, dtype=torch.long)
                if 'logit' in out[aid]:
                    p = torch.softmax(out[aid]['logit'], dim=-1).detach().cpu().numpy()
                    probs[aid] = p[0] if p.ndim == 2 else p
            else:
                actions[aid] = torch.tensor([0], device=DEVICE, dtype=torch.long)
                probs[aid] = None

        # 아군 2명 행동만 넘기면, 적군 4명은 env 내부에서 랜덤 생성/합쳐 전송됨:contentReference[oaicite:6]{index=6}
        step_result = env.step(actions)                          # {'obs','reward','done','info'} 반환:contentReference[oaicite:7]{index=7}

        # 관측/보상/종료 업데이트
        next_obs = step_result['obs']
        rew      = step_result['reward']
        done     = step_result['done']
        for aid in agent_ids:
            ep_ret[aid] += float(rew.get(aid, 0.0))

        if PRINT_STEP:
            log = []
            for aid in agent_ids:
                act_i = int(actions[aid].item())
                r_i = float(rew.get(aid, 0.0))
                prob_i = "NA" if probs.get(aid) is None else np.round(probs[aid], 3)
                log.append(f"{aid}: Act={act_i}, Rew={r_i:.2f}, Prob={prob_i}")
            print(f"[Step {step+1}] " + " | ".join(log))

        # 다음 관측 텐서 구성
        obs_tensor = {aid: torch.tensor(next_obs[aid], dtype=torch.float32).unsqueeze(0).to(DEVICE)
                      for aid in agent_ids}
        done_all = bool(done.get("__all__", False))
        step += 1

    team_sum = sum(ep_ret.values())
    print(f"[EPISODE {episode_idx+1} END] team_sum={team_sum:.3f} | per_agent_sum={ep_ret} | steps={step}")
    episode_idx += 1

env.close()
print("\n[DONE] Evaluation finished.")
