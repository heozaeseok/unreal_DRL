import torch.nn.functional as F
import numpy as np
import torch
from easydict import EasyDict
from ding.model import VAC
from ding.policy import PPOPolicy
from ding.utils import set_pkg_seed
from ding.torch_utils import to_device
from tensorboardX import SummaryWriter
from multi_agent_env import SocketMultiAgentEnv
import matplotlib.pyplot as plt
import random
import os
from datetime import datetime
import threading, time

class EnvKeepAlive:
    def __init__(self, env, interval=0.3):
        self.env = env
        self.interval = interval
        self._stop = False
        self._t = threading.Thread(target=self._run, daemon=True)
    def _run(self):
        while not self._stop:
            try:
                if hasattr(self.env, "server") and hasattr(self.env.server, "keepalive"):
                    self.env.server.keepalive()
            except Exception:
                pass
            time.sleep(self.interval)
    def __enter__(self):
        self._t.start(); return self
    def __exit__(self, exc_type, exc, tb):
        self._stop = True; self._t.join(timeout=1)


# ===== 설정 =====
TOTAL_STEPS = 500000
reward_scale = 0.1
win_reward = 50

# ===== 환경 초기화 =====
env = SocketMultiAgentEnv({
    'map_size': 7000,
    'max_step': 1000,
    'win_reward': win_reward,
    'num_detectable': 4,
    'num_agents': 2
})

agent_ids = env.agent_ids
OBS_SHAPE = env.observation_space[agent_ids[0]].shape[0]
ACTION_DIM = env.action_space[agent_ids[0]].n

config = dict(
    type='ppo',
    action_space='discrete',
    cuda=True,
    multi_gpu=False,
    on_policy=True,
    priority=False,
    priority_IS_weight=False,
    multi_agent=True,
    recompute_adv=True,
    transition_with_policy_data=True,
    nstep_return=False,

    model=dict(
        obs_shape=OBS_SHAPE,
        action_shape=ACTION_DIM,
        encoder_hidden_size_list=[128, 128, 64],
        actor_head_hidden_size=64,
        actor_head_layer_num=2,
        critic_head_hidden_size=64,
        critic_head_layer_num=2,
        share_encoder=True,
        action_space='discrete',
        activation=torch.nn.ReLU(),
        norm_type='LN',
    ),
    learn=dict(
        epoch_per_collect=4,       # 한 번 데이터 수집 후(collect) 학습 에폭 반복 횟수
                                # ↑ 높이면 같은 데이터로 더 많이 업데이트 → 데이터 효율 ↑, 과적합 위험 ↑
                                # ↓ 낮추면 업데이트 보수적, 수렴 느려짐

        batch_size=512,             # 학습 시 미니배치 크기
                                # ↑ 크면 gradient 안정성 ↑, GPU 효율 ↑, 하지만 업데이트 빈도 ↓
                                # ↓ 작으면 업데이트 빈도 ↑, gradient 변동성 ↑

        learning_rate=3e-4,        # 학습률
                                # ↑ 빠른 수렴 가능, 발산 위험 ↑
                                # ↓ 안정성 ↑, 수렴 느려짐

        lr_scheduler={
                        'type': 'cosine',
                        'epoch_num': 2000,   # 총 학습 에폭 수(업데이트*epoch_per_collect) 근사치
                        'min_lr': 1e-5,
                        'min_lr_lambda': 0.1,      
                    },                       # 학습률 스케줄러 설정 (예: 'linear', 'cosine')
                                             # None이면 고정 학습률 사용, 스케줄러 사용 시 장기 학습 안정성 ↑

        value_weight=0.5,          # Value loss 가중치 (critic 손실 비중)
                                # ↑ 가치 함수 정확성 ↑, 정책 업데이트 속도 ↓
                                # ↓ 정책 업데이트 비중 ↑, 가치 추정 부정확 가능

        entropy_weight=0.01,       # 엔트로피 보너스 가중치 (탐험성)
                                # ↑ 탐험 ↑, 수렴 느려짐
                                # ↓ 탐험 ↓, 수렴 빨라짐 but 국소최적 해 위험 ↑

        clip_ratio=0.15,            # PPO 클리핑 비율 ε
                                # ↑ 정책 변화 폭 ↑, 발산 위험 ↑
                                # ↓ 정책 변화 폭 ↓, 안정성 ↑ but 수렴 느림

        adv_norm=True,             # Advantage 값 정규화 여부
                                # True → 업데이트 안정성 ↑
                                # False → 원본 값 사용, 스케일 변화에 민감

        value_norm=True,           # Value 타겟 정규화 여부
                                # True → 안정성 ↑, 값 스케일에 덜 민감
                                # False → raw value 사용

        ppo_param_init=True,       # PPO 권장 초기화 사용 여부
                                # True → 논문 권장 초기화로 학습 안정성 ↑

        grad_clip_type='clip_norm',# Gradient 클리핑 방식
                                # 'clip_norm' → 전체 norm 제한
                                # 'clip_value' → 값 자체 제한

        grad_clip_value=1,         # Gradient 클리핑 한계 값
                                # ↑ 크면 업데이트 폭 큼, 폭발 위험 ↑
                                # ↓ 안정성 ↑, 너무 작으면 업데이트 너무 미세

        ignore_done=False,         # done=True일 때 상태 리셋 여부
                                # True → 환경 종료 무시, 계속 학습
                                # False → 에피소드 종료 시 advantage 계산 초기화
    ),

    collect=dict(
        unroll_len=1,               # rollout 길이 (n-step 수집)
                                    # ↑ 길면 GAE 계산에 더 많은 미래 보상 반영, 메모리 사용 ↑
                                    # ↓ 길면 즉시 업데이트 가능 but 장기 보상 반영 ↓

        discount_factor=0.99,       # 감가율 γ
                                    # ↑ 미래 보상 중요도 ↑, 변동성 ↑
                                    # ↓ 즉시 보상 비중 ↑, 장기전략 학습 ↓

        gae_lambda=0.97,            # GAE(Generalized Advantage Estimation) 람다 값
                                    # ↑ 1.0에 가까우면 장기 의존성 ↑, 변동성 ↑
                                    # ↓ 단기 의존성 ↑, 안정적이나 장기 정보 손실
    ),

    other=dict(
        eps=dict(
            type='exp', start=1.0, end=0.05, decay=5000
        )
    )
)
cfg = EasyDict(config)

set_pkg_seed(0, use_cuda=cfg.cuda)
device = torch.device('cuda' if cfg.cuda else 'cpu')

model = VAC(**cfg.model).to(device)
policy = PPOPolicy(cfg, model=model)
writer = SummaryWriter('./tensorlog_ppo_multi')

obs = env.reset()
obs_tensor = {aid: torch.tensor(obs[aid], dtype=torch.float32).unsqueeze(0).to(device) for aid in agent_ids}

transition_buffer = []
global_step = 0
epsilon = 1.0
epsilon_end = 0.05
epsilon_decay = 30000

episode_rewards_by_agent = {aid: [] for aid in agent_ids}
buffers = {aid: [] for aid in agent_ids}

learn_count = 0  # 학습 호출 횟수 카운터

while global_step < TOTAL_STEPS:
    done = {aid: False for aid in agent_ids}
    done["__all__"] = False
    episode_reward = {aid: 0. for aid in agent_ids}
    episode_step = 0  

    while not done["__all__"]:
        with torch.no_grad():
            collect_output = policy.collect_mode.forward(obs_tensor)

        actions = {}
        for aid in agent_ids:
            if random.random() < epsilon:
                actions[aid] = torch.tensor([env.action_space[aid].sample()], device=device)
            else:
                actions[aid] = collect_output[aid]['action']

        logits = {aid: collect_output[aid]['logit'] for aid in agent_ids}
        values = {aid: collect_output[aid]['value'] for aid in agent_ids}

        print(f"[GLOBAL STEP {global_step}] [EPISODE STEP {episode_step}] [EPOCH {learn_count}] Actions: " +
            ", ".join([f"{aid}: {actions[aid].item()}" for aid in agent_ids]))


        step_result = env.step(actions)
        next_obs_tensor = {
            aid: torch.tensor(o, dtype=torch.float32).unsqueeze(0).to(device)
            for aid, o in step_result['obs'].items()
        }
        done = step_result['done']

        # Step 업데이트
        global_step += 1
        episode_step += 1
        epsilon = max(epsilon_end, epsilon - (1.0 - epsilon_end) / epsilon_decay)

        # 중간 모델 저장
        if global_step % 100000 == 0:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            save_dir = r"C:\Users\CIL\Desktop\DI-engine-main\unreal\learned_models"
            os.makedirs(save_dir, exist_ok=True)
            save_path = os.path.join(save_dir, f"ppo_model_step{global_step}_{timestamp}.pth")
            torch.save(policy._state_dict_learn(), save_path)
            print(f"[AUTO-SAVED] Step {global_step} → {save_path}")

            # === 10만 step마다 보상 그래프 저장 ===
            save_dir_plot = r"C:\Users\CIL\Desktop\DI-engine-main\unreal\learn_resert"
            os.makedirs(save_dir_plot, exist_ok=True)

            episode_counts = [len(episode_rewards_by_agent[aid]) for aid in agent_ids]
            if episode_counts and min(episode_counts) >= 10:
                min_len = min(episode_counts)

                # 최근 10개 에피소드 평균
                avg_rewards_by_agent = {}
                for aid in agent_ids:
                    avg_rewards_by_agent[aid] = [
                        np.mean(episode_rewards_by_agent[aid][max(0, i-9):i+1])
                        for i in range(min_len)
                    ]

                plt.figure(figsize=(10, 6))
                for aid in agent_ids:
                    plt.plot(
                        range(1, min_len + 1),
                        avg_rewards_by_agent[aid],
                        marker='o', markersize=4, alpha=0.7,
                        label=f'{aid} (10-ep avg)'
                    )
                plt.xlabel('Episode')
                plt.ylabel('Average Reward (last 10 episodes)')
                plt.title(f'10-Episode Average Reward per Agent (Step {global_step})')
                plt.legend()
                plt.grid(True)
                plt.tight_layout()

                plot_path = os.path.join(save_dir_plot, f"rewards_step{global_step}.png")
                plt.savefig(plot_path)
                plt.close()
                print(f"[PLOT SAVED] {plot_path}")
            else:
                print("[PLOT] 에피소드가 10개 미만이라 중간 그래프 생성을 건너뜁니다.")
                
        # --- transition 생성: 에이전트별 버퍼에 시간순으로 저장 ---
        for aid in agent_ids:
            scaled_reward = step_result['reward'][aid] * reward_scale
            transition = {
                'obs':      obs_tensor[aid].squeeze(0),
                'next_obs': next_obs_tensor[aid].squeeze(0),
                'action':   actions[aid].squeeze(0),
                'logit':    logits[aid].squeeze(0),
                'value':    values[aid].squeeze(0),
                'reward':   torch.tensor(scaled_reward, dtype=torch.float32),
                'done':     torch.tensor(float(done[aid]), dtype=torch.float32),
            }
            buffers[aid].append(transition)
            episode_reward[aid] += scaled_reward

        obs_tensor = next_obs_tensor

        # 에피소드 종료 처리
        if done["__all__"]:
            print(f"[EP DONE] Global Step: {global_step}, Rewards: {episode_reward}")
            for aid in agent_ids:
                episode_rewards_by_agent[aid].append(episode_reward[aid])
            obs = env.reset()
            obs_tensor = {aid: torch.tensor(obs[aid], dtype=torch.float32).unsqueeze(0).to(device)
                        for aid in agent_ids}  # ★ 아군 ID 기준으로만 텐서화

    # --- 학습 조건 충족 시: 에이전트별 시퀀스 병합 → 학습 → 버퍼 클리어 ---
    if sum(len(buffers[aid]) for aid in agent_ids) >= 4096:
        all_tr = []
        for aid in agent_ids:
            all_tr.extend(buffers[aid])    # 각 에이전트의 연속 시퀀스를 보존한 채 병합
            buffers[aid].clear()           # on-policy 보장

        train_data = policy._get_train_sample(all_tr)
        train_data = [
            {
                k: (
                    torch.tensor(v, dtype=torch.float32).to(device)
                    if isinstance(v, (bool, np.bool_)) else
                    v.to(device) if isinstance(v, torch.Tensor) else v
                )
                for k, v in t.items()
            }
            for t in train_data
        ]

        with EnvKeepAlive(env, interval=0.3):
            learn_output = policy._forward_learn(train_data)
        learn_count += 1  # 학습 횟수 증가
        print(f"[LEARN] {learn_output}")

# 종료
env.close()

timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
save_dir = r"C:\Users\CIL\Desktop\DI-engine-main\unreal\learned_models"
os.makedirs(save_dir, exist_ok=True)
save_path = os.path.join(save_dir, f"ppo_model_{timestamp}.pth")

torch.save(policy._state_dict_learn(), save_path)
print(f"[SAVED] {save_path}")

# === 보상 시각화: 최근 10개 평균 보상 (에이전트별) ===
episode_counts = [len(episode_rewards_by_agent[aid]) for aid in agent_ids]
if episode_counts and min(episode_counts) >= 10:
    min_len = min(episode_counts)
    avg_rewards_by_agent = {}
    for aid in agent_ids:
        avg_rewards_by_agent[aid] = [
            np.mean(episode_rewards_by_agent[aid][max(0, i-9):i+1])
            for i in range(min_len)
        ]

    plt.figure(figsize=(10, 6))
    for aid in agent_ids:
        plt.plot(range(1, min_len + 1), avg_rewards_by_agent[aid],
                 marker='o', markersize=4, alpha=0.7, label=f'{aid} (10-ep avg)')
    plt.xlabel('Episode')
    plt.ylabel('Average Reward (last 10 episodes)')
    plt.title('10-Episode Average Reward per Agent (Final)')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()

    save_dir_plot = r"C:\Users\CIL\Desktop\DI-engine-main\unreal\learn_resert"
    os.makedirs(save_dir_plot, exist_ok=True)
    plot_path = os.path.join(save_dir_plot, f"rewards_final.png")
    plt.savefig(plot_path)
    plt.close()
    print(f"[PLOT SAVED] {plot_path}")
else:
    print("[WARN] 최소 10개 이상의 완료된 에피소드가 필요합니다.")