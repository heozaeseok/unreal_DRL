import numpy as np
from gym import spaces
from ding.envs import BaseEnv, BaseEnvTimestep
from socket_server import SocketServer
from ding.utils import ENV_REGISTRY
from ding.torch_utils.data_helper import to_ndarray

@ENV_REGISTRY.register('socket_env')
class SocketEnv(BaseEnv):
    def __init__(self, cfg):
        self._cfg = cfg
        self._init_flag = False
        self.max_step = cfg.get('max_step', 1000) #에피소드당 최대 스텝수 조정
        self.map_size = cfg.get('map_size', 4000)
        self.win_reward = cfg.get('win_reward', 5.0)
        self.num_detectable = cfg.get('num_detectable', 4) #💫💫💫

        obs_dim = 4 + self.num_detectable * 4  #💫💫💫
        self._observation_space = spaces.Box(low=-self.map_size, high=self.map_size, shape=(obs_dim,), dtype=np.float32) #💫💫💫
        self._action_space = spaces.Discrete(5) #💫💫💫

    def reset(self):
        print("=== [RESET CALL] ===")
        self.server = SocketServer()
        self.server.start()

        self.step_count = 0
        if hasattr(self, '_seed') and hasattr(self, '_dynamic_seed') and self._dynamic_seed:
            np_seed = 100 * np.random.randint(1, 1000)
            np.random.seed(self._seed + np_seed)
        elif hasattr(self, '_seed'):
            np.random.seed(self._seed)

        self.server.send({
            "Agents": [
                {
                    "UnitID": "AgentCharacter",
                    "Order": int(np.random.randint(1, 6)),
                    "Pitch": 0,
                    "Yaw": 0,     # 필요한 경우 방향 값으로 변경 가능
                    "Roll": 0
                }
            ]
        })

        last_data = None

        for _ in range(20):
            data = self.server.receive()
            if data is not None:
                try:
                    agent_data = data["Agents"][0]
                    self.current_obs = self._convert_obs(agent_data)
                    self._eval_episode_return = 0.
                    return to_ndarray(self.current_obs)
                except Exception as e:
                    print(f"[RESET ERROR] Invalid agent data: {e}")
                    continue

        print("[ERROR] No valid data received after 20 attempts.")
        return None

    def step(self, action):
        assert isinstance(action, np.ndarray), type(action)
        action = action.item()

        self.server.send({
            "Agents": [
                {
                    "UnitID": "AgentCharacter",
                    "Order": int(action),
                    "Pitch": 0,
                    "Yaw": 0,     # 필요한 경우 방향 값으로 변경 가능
                    "Roll": 0
                }
            ]
        })
        
        data = self.server.receive()
        self.step_count += 1

        if not data:
            return BaseEnvTimestep(to_ndarray(self.current_obs), to_ndarray([0.]), True, {})

        agent_data = data["Agents"][0]
        obs = self._convert_obs(agent_data)
        reward = float(agent_data.get("Reward", 0.)) - 0.01
        done = bool(agent_data.get("isDone", False))

        if agent_data.get("HP", 0) <= 0:
            done = True

        if done:
            if obs[3] > 0:
                reward += self.win_reward
            else:
                reward -= 3.0

        self.current_obs = obs
        self._eval_episode_return += reward

        info = {}
        if done:
            info['eval_episode_return'] = self._eval_episode_return

        return BaseEnvTimestep(
            obs=to_ndarray(obs),
            reward=to_ndarray([reward], dtype=np.float32),
            done=done,
            info=info
        )

    def random_action(self) -> np.ndarray:
        random_action = self._action_space.sample()
        if isinstance(random_action, np.ndarray):
            return random_action
        elif isinstance(random_action, int):
            return to_ndarray([random_action], dtype=np.int64)
        elif isinstance(random_action, dict):
            return to_ndarray(random_action)
        else:
            raise TypeError(
                f"random_action should return int/np.ndarray or dict, but got {type(random_action)}: {random_action}"
            )

    def close(self):
        self.server.close()

    def _convert_obs(self, data):
        # 자가 위치 및 체력
        obs = [
            float(data.get("LocX", 0)),
            float(data.get("LocY", 0)),
            float(data.get("LocZ", 0)),
            data.get("HP", 0)
        ]

        # 고정된 순서로 적군 ID 리스트 정의
        fixed_enemy_names = [
            "AgentCharacter2",
            "AgentCharacter3",
            "AgentCharacter4",
            "AgentCharacter5"
        ]

        # 적군 정보 초기화 (0으로 채움)
        for _ in fixed_enemy_names:
            obs += [0, 0, 0, 0]

        detect_list = data.get("DetectActors", [])
        for enemy in detect_list:
            name = enemy.get("Name", "")
            if name in fixed_enemy_names:
                idx = fixed_enemy_names.index(name)  # 몇 번째 적군인지
                base = 4 + idx * 4  # obs에서의 시작 위치

                obs[base:base+4] = [
                    float(enemy.get("LocX", 0)),
                    float(enemy.get("LocY", 0)),
                    float(enemy.get("LocZ", 0)),
                    enemy.get("HP", 0)
                ]

        obs = np.array(obs, dtype=np.float32)

        # === 정규화 ===
        obs[0:3] = obs[0:3] / self.map_size  # 자가 위치 정규화
        for i in range(len(fixed_enemy_names)):
            idx = 4 + i * 4
            obs[idx:idx+3] = obs[idx:idx+3] / self.map_size  # 적 위치 정규화 (HP는 그대로)

        return np.round(obs, 5)

    def seed(self, seed: int = 0, dynamic_seed: bool = False) -> None:
        self._seed = seed
        self._dynamic_seed = dynamic_seed
        np.random.seed(self._seed)

    def __repr__(self):
        return "SocketEnv()"

    @property
    def observation_space(self):
        return self._observation_space

    @property
    def action_space(self):
        return self._action_space

    @property
    def reward_space(self):
        return spaces.Box(low=-10.0, high=10.0, shape=(1,), dtype=np.float32)
