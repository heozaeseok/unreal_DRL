import numpy as np
import torch
from easydict import EasyDict
from ding.model import VAC
from ding.policy import PPOPolicy
from ding.utils import set_pkg_seed
from ding.torch_utils import to_device, unsqueeze
from tensorboardX import SummaryWriter
from socket_env import SocketEnv
from ding.envs import BaseEnvTimestep

# ===== 설정 =====
TOTAL_STEPS = 100000

win_reward = 50
reward_scale = 0.1

# ===== PPO 수집 및 학습 =====
global_step = 0
episode_idx = 0
episode_reward = 0
all_episode_rewards = []  
probs_history = []  # 행동 확률 저장
learn_steps = []    # 학습 시점 저장

epsilon = 1.0  # 1.0
epsilon_end = 0.05  # 0.05
epsilon_decay = 20000  # 10000

transition_buffer = []
min_transitions = 1024 # 총알데미지 고려해서 최적횟수 조정

# ===== 환경 초기화 =====
env = SocketEnv({
    'map_size': 4000,
    'max_step': 1000,
    'win_reward': 50,
    'num_detectable': 2 #💫💫💫
})

OBS_SHAPE = env.observation_space.shape[0] #💫💫💫
ACTION_DIM = env.action_space.n #💫💫💫
print(OBS_SHAPE)
print("CUDA available:", torch.cuda.is_available())

config = dict(
    type='ppo',
    cuda=True,
    multi_gpu=False,
    on_policy=True,
    priority=False,
    priority_IS_weight=False,
    recompute_adv=True,
    action_space='discrete',
    nstep_return=False,
    multi_agent=False,
    transition_with_policy_data=True,

    model=dict(
        obs_shape=OBS_SHAPE,
        action_shape=ACTION_DIM,
        encoder_hidden_size_list=[128, 128, 64],
        actor_head_hidden_size=64,
        actor_head_layer_num=2,
        critic_head_hidden_size=64,
        critic_head_layer_num=2,
        share_encoder=True,
        action_space='discrete',
        activation=torch.nn.ReLU(),
        norm_type='LN',
    ),

    learn=dict(
        epoch_per_collect=4, #수집한 데이터를 몇 번 반복해서 학습할지, 데이터를 얼마나 재사용할지
        batch_size=128, #배치사이즈
        learning_rate=3e-4, #작게세팅하면 조금씩해서 로컬로 수렴안하게
        lr_scheduler=None,
        value_weight=0.5,
        entropy_weight=0.01, # 탐험정도, softmax 분포를 더 평평하게 만들어, 다양한 행동 선택 유도, 수렴이 느려질 수 있음
        clip_ratio=0.2, # 높을수록 정책이 급변, 기존정책에서 몇퍼센트 변화를 허용하는지, 0.10 -> 10% 변화 허용 그 이상은 X
        adv_norm=True, #false or true / 정규화 여부 중요
        value_norm=True, #false or true / 정규화 여부 중요 / 이거 켜면 nan으로 꽉차는 오류발생생
        ppo_param_init=True,
        grad_clip_type='clip_norm',
        grad_clip_value=1,
        ignore_done=False,
    ),

    collect=dict(
        unroll_len=1,
        discount_factor=0.99,
        gae_lambda=0.95,
    ),

    eval=dict(
        evaluator=dict(
            eval_freq=1000,
            n_episode=5,
            render=False,
        )
    ),

    other=dict(
        eps=dict( 
            type='exp',
            start=1.0,
            end=0.05,
            decay=5000,
        )
    ),
)

cfg = EasyDict(config)


# ===== 초기화 =====
set_pkg_seed(0, use_cuda=cfg.cuda)
obs = env.reset()
model = VAC(**cfg.model)
print(model.actor)
device = 'cuda' if cfg.cuda else 'cpu'
model.to(device)
first_obs = torch.tensor(obs, dtype=torch.float32).unsqueeze(0).to(device)
obs_tensor = first_obs.clone()


for _ in range(5):
    dummy_obs = torch.rand_like(obs_tensor).to(device)
    out = model(dummy_obs, mode='compute_actor')['logit']
    probs = torch.softmax(out, dim=-1)
    print("logits:", out)
    print("probs:", probs)
#초반 로짓 확인용 (초기화가 잘 되었는지)


policy = PPOPolicy(cfg, model=model)
writer = SummaryWriter('./tensorlog_ppo')

print("CUDA available:", torch.cuda.is_available())

#torch.autograd.set_detect_anomaly(True) 
#오류 찾는 코드?



while global_step < TOTAL_STEPS:
    step = 0
    done = False
    episode_reward = 0

    while not done and step < env.max_step:
        with torch.no_grad():
            collect_output = policy.collect_mode.forward({0: obs_tensor})[0]

        logits = collect_output['logit']
        probs = torch.nn.functional.softmax(logits, dim=-1)
        probs_history.append(probs.squeeze(0).detach().cpu().numpy().tolist())

        print("[STEP]", global_step, "[DEBUG] probs:", [[f"{v:.5f}" for v in row] for row in np.round(probs.cpu().numpy(), 5)])

        if np.random.rand() < epsilon:
            action = np.random.randint(ACTION_DIM)
        else:
            action = collect_output['action'].item()

        timestep = env.step(np.array([action], dtype=np.int64))

        obs_tensor_next = timestep.obs
        obs_tensor_next_unsqueezed = torch.tensor(obs_tensor_next, dtype=torch.float32).unsqueeze(0).to(device)
        done_tensor = torch.tensor(timestep.done, dtype=torch.float32)
        reward = timestep.reward[0]

        #print(f"[STEP {global_step}] obs:", obs_tensor_next_unsqueezed)

        if timestep.done and timestep.obs[3] > 0 and step < 999:
            reward += win_reward

        scaled_reward = reward * reward_scale
        reward_tensor = torch.tensor(scaled_reward, dtype=torch.float32)

        transition = {
            'obs': obs_tensor.squeeze(0),
            'next_obs': obs_tensor_next_unsqueezed.squeeze(0),
            'action': collect_output['action'].squeeze(0),
            'logit': collect_output['logit'].squeeze(0),
            'value': collect_output['value'].squeeze(0),
            'reward': reward_tensor,
            'done': done_tensor,
        }
        transition_buffer.append(transition)

        obs = timestep.obs
        obs_tensor = obs_tensor_next_unsqueezed
        episode_reward += reward_tensor.item()
        global_step += 1
        step += 1
        done = timestep.done
        epsilon = max(epsilon_end, epsilon - (cfg.other.eps.start - epsilon_end) / epsilon_decay)

    print(f"[TOTAL_STEP] : {global_step}, [EP {episode_idx}] Reward: {episode_reward:.2f}, Steps: {step}")
    writer.add_scalar("episode_reward", episode_reward, global_step)
    all_episode_rewards.append(episode_reward)
    episode_idx += 1

    obs = env.reset()
    if obs is None or np.isnan(obs).any():
        print("[ERROR] Reset returned invalid obs, skipping episode.")
        continue
    first_obs = torch.tensor(obs, dtype=torch.float32).unsqueeze(0).to(device)
    obs_tensor = first_obs.clone()

    #transition 수 기반
    if len(transition_buffer) >= min_transitions:
        train_data = policy._get_train_sample(transition_buffer)

        for t in train_data:
            for key in t:
                if isinstance(t[key], torch.Tensor):
                    t[key] = t[key].to(device)
                elif isinstance(t[key], (bool, np.bool_)):
                    t[key] = torch.tensor(float(t[key]), dtype=torch.float32).to(device)

        if len(train_data) > 1:
            print(f">>> [POLICY LEARN] step {global_step} | {len(transition_buffer)} transitions")
            learn_output = policy._forward_learn(train_data)
            learn_steps.append(global_step)

            for name, param in policy._learn_model.named_parameters():
                if param.grad is not None:
                    print(f"[GRAD] {name} grad norm: {param.grad.norm().item():.6f}")

            print("=== Learn Output ===")
            print(learn_output)
            for stat in learn_output:
                for k, v in stat.items():
                    writer.add_scalar(k, v, global_step)

        transition_buffer.clear()
# 종료 시 환경 닫기
env.close()

#모델 저장
save_path = "C:/Users/CIL2/Desktop/DI-engine-main/unreal/learned_models/ppo_model_env3.pth"
torch.save(policy._learn_model.state_dict(), save_path)
print(f"[MODEL SAVED] to {save_path}")

# ===== 보상 그래프 =====
import matplotlib.pyplot as plt

episode_rewards = all_episode_rewards 
avg_rewards = []
window_size = 10
for i in range(len(episode_rewards)):
    start = max(0, i - window_size + 1)
    avg_rewards.append(np.mean(episode_rewards[start:i+1]))

plt.figure(figsize=(10, 5))
plt.plot(episode_rewards, label='Episode Reward', alpha=0.5, color='blue')
plt.plot(avg_rewards, label='10-Episode Moving Avg', linewidth=2, color='orange')
plt.title("Episode Rewards over Time (PPO)")
plt.xlabel("Episode")
plt.ylabel("Reward")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()

# ===== 행동 확률 그래프 =====
probs_array = np.array(probs_history)

plt.figure(figsize=(12, 6))
for i in range(probs_array.shape[1]):
    plt.plot(probs_array[:, i], label=f'Action {i}')

for step in learn_steps:
    plt.axvline(x=step, color='gray', linestyle='--', alpha=0.6, label='Learn Step' if step == learn_steps[0] else "")

plt.title("Action Probability over Time")
plt.xlabel("Step")
plt.ylabel("Probability")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()