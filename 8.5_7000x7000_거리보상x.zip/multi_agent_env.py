from socket_server import SocketServer
from ding.envs import BaseEnv
from ding.utils import ENV_REGISTRY
from ding.torch_utils.data_helper import to_ndarray
from gym import spaces
import numpy as np
import time

@ENV_REGISTRY.register('socket_multi_env')
class SocketMultiAgentEnv(BaseEnv):
    def __init__(self, cfg):
        self._cfg = cfg
        self.max_step = cfg.get('max_step', 1000)
        self.map_size = cfg.get('map_size', 4000)
        self.win_reward = cfg.get('win_reward', 100)
        self.num_detectable = cfg.get('num_detectable', 4)
        self.num_agents = cfg.get('num_agents', 2)
        self.agent_ids = ["AgentCharacter", "AgentCharacter2"]
        self.last_data = {}

        obs_dim = 4 + (self.num_agents - 1) * 4 + self.num_detectable * 4
        self._observation_space = spaces.Box(low=-self.map_size, high=self.map_size, shape=(obs_dim,), dtype=np.float32)
        self._action_space = spaces.Discrete(12)

    def reset(self):
        print("=== [RESET CALL] ===")
        self.server = SocketServer()
        self.server.start()
        self.step_count = 0
        self.last_done = {aid: False for aid in self.agent_ids}
        self.last_data = {} 

        self.server.send({
            "Agents": [{"UnitID": aid, "Order": 0, "Pitch": 0, "Yaw": 0, "Roll": 0} for aid in self.agent_ids]
        })

        for attempt in range(20):
            data = self.server.receive()
            if data and "Agents" in data:
                try:
                    obs_dict = {}
                    for agent in data["Agents"]:
                        aid = agent["UnitID"]
                        self.last_data[aid] = agent 
                        obs_dict[aid] = to_ndarray(self._convert_obs(agent))
                    self.current_obs = obs_dict
                    self._eval_episode_return = {aid: 0. for aid in self.agent_ids}
                    return obs_dict 
                except Exception as e:
                    print(f"[RESET ERROR] Parsing failed: {e} (attempt {attempt+1})")
            time.sleep(0.1)
        print("[ERROR] No valid data received after 20 attempts.")
        return {aid: to_ndarray(np.zeros(self._observation_space.shape)) for aid in self.agent_ids}

    def step(self, action: dict):
        assert isinstance(action, dict)

        # 죽은 에이전트는 행동 0으로 고정
        self.server.send({
            "Agents": [
                {
                    "UnitID": aid,
                    "Order": 0 if self.last_done.get(aid, False) else int(action[aid].item()),
                    "Pitch": 0,
                    "Yaw": 0,
                    "Roll": 0
                } for aid in self.agent_ids
            ]
        })

        data = self.server.receive()

        if isinstance(data, str) and data.strip() == "EpiDone":
            print("[INFO] EpiDone received. Forcing episode termination.")
            return self._dummy_timestep(done_all=True)

        if not isinstance(data, dict) or "Agents" not in data:
            print("[ERROR] No valid agent data received.")
            return self._dummy_timestep(done_all=True)

        obs, rew, done, info = {}, {}, {}, {}
        positions = {}
        distance_bonus_dict = {}

        # 거리 기반 보상 설정값
        DISTANCE_REWARD_POSITIVE = 0.2   # 양수 보상
        DISTANCE_REWARD_NEGATIVE = -0.1  # 벌점
        DISTANCE_MIN = 0.1               # 보상 줄 최소 거리
        DISTANCE_MAX = 0.25               # 보상 줄 최대 거리

        # 기본 정보 처리
        for agent in data["Agents"]:
            aid = agent["UnitID"]
            if aid not in self.agent_ids:
                continue

            is_dead = bool(agent.get("isDone", False)) or agent.get("HP", 0) <= 0
            self.last_done[aid] = is_dead
            self.last_data[aid] = agent

            obs_val = self._convert_obs(agent)
            if is_dead:
                obs[aid] = to_ndarray(np.full_like(obs_val, -1.0, dtype=np.float32))
            else:
                obs[aid] = to_ndarray(obs_val)
                positions[aid] = obs_val[:2]

            reward = float(agent.get("Reward", 0.))
            rew[aid] = reward
            done[aid] = is_dead
            info[aid] = {}
            self._eval_episode_return[aid] += reward

        self.current_obs = obs

        # 거리 기반 보상 계산 (고정 보상 방식)
        for aid in self.agent_ids:
            if not self.last_done.get(aid, True) and aid in positions:
                my_pos = positions[aid]
                distance_bonus = 0.0
                for other_id, other_pos in positions.items():
                    if other_id == aid:
                        continue
                    dist = np.linalg.norm(my_pos - other_pos)

                    if DISTANCE_MIN <= dist <= DISTANCE_MAX:
                        proximity_reward = DISTANCE_REWARD_POSITIVE
                        #print(f"{aid} gets POSITIVE proximity reward (dist={dist:.3f})")
                    else:
                        proximity_reward = DISTANCE_REWARD_NEGATIVE
                        #print(f"{aid} gets NEGATIVE proximity penalty (dist={dist:.3f})")

                    #distance_bonus += proximity_reward
                distance_bonus_dict[aid] = distance_bonus

        # 방어: 누락된 에이전트에 기본값 보장
        for aid in self.agent_ids:
            if aid not in obs:
                obs[aid] = to_ndarray(np.full(self._observation_space.shape, -1.0, dtype=np.float32))
            if aid not in rew:
                print(f"[WARN] Missing reward for {aid}, assigning 0.0")
                rew[aid] = 0.0
            if aid not in done:
                done[aid] = True
            if aid not in info:
                info[aid] = {}

        # 에피소드 종료 여부 판단
        done["__all__"] = all(done[aid] for aid in self.agent_ids)

        if done["__all__"]:
            alive_agents = []
            for agent in data["Agents"]:
                aid = agent["UnitID"]
                if float(agent.get("HP", 0)) > 0:
                    alive_agents.append(aid)

            if len(alive_agents) > 0:
                for aid in self.agent_ids:
                    rew[aid] += self.win_reward
                print("[ENV] Win reward granted to all agents.")
            else:
                for aid in self.agent_ids:
                    rew[aid] = -self.win_reward
                print("[ENV] Loss penalty applied to all agents.")
        else:
            # 진행 중일 때만 거리 보상 적용
            for aid in self.agent_ids:
                rew[aid] += distance_bonus_dict.get(aid, 0.0)

        return {
            'obs': obs,
            'reward': rew,
            'done': done,
            'info': info
        }

    def _dummy_timestep(self, done_all: bool = False):
        dummy_obs = {aid: to_ndarray(self.current_obs.get(aid, np.zeros(self._observation_space.shape)))
                     for aid in self.agent_ids}
        rew = {aid: 0.0 for aid in self.agent_ids}
        done = {aid: done_all for aid in self.agent_ids}
        done["__all__"] = done_all
        info = {aid: {} for aid in self.agent_ids}


        return {
            'obs': dummy_obs,
            'reward': rew,
            'done': done,
            'info': info
        }

    def _convert_obs(self, data):
        self_id = data.get("UnitID")
        self_x = float(data.get("LocX", 0))
        self_y = float(data.get("LocY", 0))
        self_z = float(data.get("LocZ", 0))
        self_hp = float(data.get("HP", 0))

        # 내 위치 및 체력 (절대좌표)
        obs = [self_x / 7000, self_y / 7000, self_z / 700, self_hp / 100]

        # 아군의 위치 및 체력 추가
        for other_agent in self.agent_ids:
            if other_agent == self_id:
                continue
            other_data = self.last_data.get(other_agent)
            if other_data:
                ox = float(other_data.get("LocX", 0)) / 7000
                oy = float(other_data.get("LocY", 0)) / 7000
                oz = float(other_data.get("LocZ", 0)) / 700
                ohp = float(other_data.get("HP", 0)) / 100
                obs.extend([ox, oy, oz, ohp])
            else:
                obs.extend([0.0, 0.0, 0.0, 0.0])  # default padding if no data yet

        # 적 정보 초기화
        obs.extend([0.0, 0.0, 0.0, 0.0] * self.num_detectable)

        # 감지된 적의 위치 및 존재 여부
        fixed_enemy_names = [f"AgentCharacter{i+3}" for i in range(self.num_detectable)]
        for enemy in data.get("DetectActors", []):
            name = enemy.get("Name", "")
            if name in fixed_enemy_names:
                idx = fixed_enemy_names.index(name)
                base = 4 + (len(self.agent_ids) - 1) * 4 + idx * 4
                ex = float(enemy.get("LocX", 0)) / 7000
                ey = float(enemy.get("LocY", 0)) / 7000
                ez = float(enemy.get("LocZ", 0)) / 700
                obs[base:base+4] = [ex, ey, ez, 1.0]  # 마지막 1.0은 존재 표시

        return np.round(np.array(obs, dtype=np.float32), 3)

    def close(self):
        self.server.close()

    def seed(self, seed: int = 0, dynamic_seed: bool = False) -> None:
        self._seed = seed
        self._dynamic_seed = dynamic_seed
        np.random.seed(self._seed)

    def random_action(self) -> dict:
        return {aid: np.array([self._action_space.sample()], dtype=np.int64) for aid in self.agent_ids}

    def __repr__(self):
        return "SocketMultiAgentEnv()"

    @property
    def observation_space(self):
        return {aid: self._observation_space for aid in self.agent_ids}

    @property
    def action_space(self):
        return {aid: self._action_space for aid in self.agent_ids}

    @property
    def reward_space(self):
        return {aid: spaces.Box(low=-10.0, high=10.0, shape=(1,), dtype=np.float32) for aid in self.agent_ids}
