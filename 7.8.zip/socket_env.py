import numpy as np
from gym import spaces
from ding.envs import BaseEnv, BaseEnvTimestep
from socket_server import SocketServer
from ding.utils import ENV_REGISTRY
from ding.torch_utils.data_helper import to_ndarray
import time

@ENV_REGISTRY.register('socket_env')
class SocketEnv(BaseEnv):
    def __init__(self, cfg):
        self._cfg = cfg
        self._init_flag = False
        self.max_step = cfg.get('max_step', 1000)
        self.map_size = cfg.get('map_size', 4000)
        self.win_reward = cfg.get('win_reward', 100)
        self.num_detectable = cfg.get('num_detectable', 4)

        obs_dim = 4 + self.num_detectable * 4
        self._observation_space = spaces.Box(low=-self.map_size, high=self.map_size, shape=(obs_dim,), dtype=np.float32)
        self._action_space = spaces.Discrete(6)

    def reset(self):
        print("=== [RESET CALL] ===")
        if hasattr(self, 'server') and self.server is not None:
            try:
                self.server.close()
                print("[RESET] Previous server closed.")
            except Exception as e:
                print(f"[WARNING] Failed to close previous server: {e}")

        self.server = SocketServer()
        self.server.start()

        self.step_count = 0
        if hasattr(self, '_seed') and hasattr(self, '_dynamic_seed') and self._dynamic_seed:
            np_seed = 100 * np.random.randint(1, 1000)
            np.random.seed(self._seed + np_seed)
        elif hasattr(self, '_seed'):
            np.random.seed(self._seed)

        try:
            self.server.send({"Agents": [{"UnitID": "AgentCharacter", "Order": 0, "Pitch": 0, "Yaw": 0, "Roll": 0}]})
        except Exception as e:
            print(f"[RESET ERROR] Failed to send initial action: {e}")
            self.server.start()  # 재연결 후 재시도

        for _ in range(20):
            data = self.server.receive()
            if data is not None:
                try:
                    agent_data = data["Agents"][0]
                    self.current_obs = self._convert_obs(agent_data)
                    self._eval_episode_return = 0.
                    return to_ndarray(self.current_obs)
                except Exception as e:
                    print(f"[RESET ERROR] Invalid agent data: {e}")
                    continue

        print("[ERROR] No valid data received after 20 attempts.")
        return None

    def step(self, action):
        assert isinstance(action, np.ndarray), type(action)
        action = action.item()

        try:
            self.server.send({"Agents": [{"UnitID": "AgentCharacter", "Order": int(action), "Pitch": 0, "Yaw": 0, "Roll": 0}]})
        except Exception as e:
            print(f"[STEP ERROR] send failed, restarting server: {e}")
            self.server.start()

        data = None
        max_retries = 3
        retry_interval = 5.0
        for attempt in range(max_retries):
            data = self.server.receive()
            if data:
                break
            else:
                print(f"[WARNING] No response (attempt {attempt+1}/{max_retries}). Retrying with action 0...")
                try:
                    self.server.send({"Agents": [{"UnitID": "AgentCharacter", "Order": 0, "Pitch": 0, "Yaw": 0, "Roll": 0}]})
                except Exception as e:
                    print(f"[FALLBACK ERROR] send failed: {e}")
                    self.server.start()
                time.sleep(retry_interval)

        self.step_count += 1

        if not data or "Agents" not in data or not data["Agents"]:
            print("[ERROR] No valid data received after retries.")
            print("=== Calling env.reset() due to communication failure ===")
            obs = self.reset()
            return BaseEnvTimestep(
                obs=to_ndarray(obs),
                reward=to_ndarray([0.], dtype=np.float32),
                done=True,
                info={"reset_called": True}
            )

        agent_data = data["Agents"][0]
        obs = self._convert_obs(agent_data)
        reward = float(agent_data.get("Reward", 0.))
        done = bool(agent_data.get("isDone", False))

        if agent_data.get("HP", 0) <= 0:
            done = True

        self.current_obs = obs
        self._eval_episode_return += reward

        info = {}
        if done:
            info['eval_episode_return'] = self._eval_episode_return

        return BaseEnvTimestep(
            obs=to_ndarray(obs),
            reward=to_ndarray([reward], dtype=np.float32),
            done=done,
            info=info
        )



    def random_action(self) -> np.ndarray:
        random_action = self._action_space.sample()
        if isinstance(random_action, np.ndarray):
            return random_action
        elif isinstance(random_action, int):
            return to_ndarray([random_action], dtype=np.int64)
        elif isinstance(random_action, dict):
            return to_ndarray(random_action)
        else:
            raise TypeError(
                f"random_action should return int/np.ndarray or dict, but got {type(random_action)}: {random_action}"
            )

    def close(self):
        self.server.close()

    def _convert_obs(self, data):
        # 자가 위치 및 체력
        self_x = float(data.get("LocX", 0))
        self_y = float(data.get("LocY", 0))
        self_z = float(data.get("LocZ", 0))
        hp = data.get("HP", 0)

        # 자기 위치는 정규화된 절대좌표로 유지
        obs = [
            self_x / 4000,
            self_y / 4000,
            self_z / 400,
            hp / 100
        ]

        # 고정된 적군 순서
        fixed_enemy_names = [
            "AgentCharacter2",
            "AgentCharacter3",
            "AgentCharacter4",
            "AgentCharacter5"
        ]

        # 초기화: 감지 안 된 적은 0 벡터 + mask = -1.0
        for _ in fixed_enemy_names:
            obs += [-1.0, -1.0, -1.0, -1.0]

        detect_list = data.get("DetectActors", [])
        for enemy in detect_list:
            name = enemy.get("Name", "")
            if name in fixed_enemy_names:
                idx = fixed_enemy_names.index(name)
                base = 4 + idx * 4  # self info = 4, 적당 4개씩

                enemy_x = float(enemy.get("LocX", 0))
                enemy_y = float(enemy.get("LocY", 0))
                enemy_z = float(enemy.get("LocZ", 0))

                # 절대좌표 → 정규화
                ex = enemy_x / 4000
                ey = enemy_y / 4000
                ez = enemy_z / 400

                obs[base:base+4] = [ex, ey, ez, 1.0]

        return np.round(np.array(obs, dtype=np.float32), 3)

    def seed(self, seed: int = 0, dynamic_seed: bool = False) -> None:
        self._seed = seed
        self._dynamic_seed = dynamic_seed
        np.random.seed(self._seed)

    def __repr__(self):
        return "SocketEnv()"

    @property
    def observation_space(self):
        return self._observation_space

    @property
    def action_space(self):
        return self._action_space

    @property
    def reward_space(self):
        return spaces.Box(low=-10.0, high=10.0, shape=(1,), dtype=np.float32)
