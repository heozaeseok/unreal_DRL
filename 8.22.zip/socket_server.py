# socket_server.py (교체)
import socket, json
import time

class SocketServer:
    def __init__(self, host='127.0.0.1', port=12345, timeout=5.0, accept_timeout=10.0):
        self.host = host
        self.port = port
        self.timeout = timeout
        self.accept_timeout = accept_timeout
        self.buffer = ""
        self.last_action = None

    def start(self):
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        try:
            self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
        except Exception:
            pass
        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen(1)
        self.server_socket.settimeout(self.accept_timeout)
        print("[SERVER] Waiting for client...")
        self._accept_client()
        print("[SERVER] Client connected.")

    def _accept_client(self):
        while True:
            try:
                self.client_socket, _ = self.server_socket.accept()
                self.client_socket.settimeout(self.timeout)
                self.client_socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                try:
                    self.client_socket.setsockopt(socket.SOL_SOCKET, socket.SO_KEEPALIVE, 1)
                except Exception:
                    pass
                self.buffer = ""
                self.last_action = None
                self._in_reset = True 
                self._warmup_until = time.time() + 2.0
                return
            except socket.timeout:
                print("[SERVER] Still waiting for client...")
                continue

    def _reconnect(self):
        try:
            if hasattr(self, "client_socket"):
                try:
                    self.client_socket.shutdown(socket.SHUT_RDWR)
                except Exception:
                    pass
                self.client_socket.close()
        except Exception:
            pass
        print("[SERVER] Re-accepting client...")
        self._accept_client()
        print("[SERVER] Reconnected.")

    def send(self, action_dict):
        msg = json.dumps(action_dict) + "@"
        self.last_action = action_dict
        try:
            self.client_socket.sendall(msg.encode("utf-8"))
        except (socket.timeout, OSError):
            self._reconnect()
            self.client_socket.sendall(msg.encode("utf-8"))

    def keepalive(self):
        try:
            self.client_socket.sendall(b'{"KeepAlive":true}@')
        except (socket.timeout, OSError):
            self._reconnect()
            self.client_socket.sendall(b'{"KeepAlive":true}@')

    def receive(self):
        try:
            while True:
                try:
                    data = self.client_socket.recv(8192)
                except socket.timeout:
                    print("[DEBUG] receive() timed out.")
                    # ★ 접속 직후 웜업 구간에는 재전송하지 않음(UE 초기화 시간 확보)
                    if getattr(self, "_in_reset", False) or (getattr(self, "_warmup_until", 0) > time.time()):
                        return None
                    if self.last_action is not None:
                        print("[DEBUG] Re-sending last action due to timeout.")
                        try:
                            self.send(self.last_action)
                        except Exception as e:
                            print(f"[ERROR] Re-send failed: {e}")
                    return None

                if not data:
                    print("[WARN] Empty read -> reconnect flow.")
                    self._reconnect()
                    continue

                decoded = data.decode("utf-8", errors="ignore").strip()
                if decoded == "EpiDone":
                    print("[INFO] 'EpiDone' received directly from client.")
                    return "EpiDone"

                self.buffer += decoded
                last_json = None
                while "@" in self.buffer:
                    raw, self.buffer = self.buffer.split("@", 1)
                    raw = raw.strip()
                    if not raw or raw == '{"KeepAlive":true}':
                        continue
                    try:
                        last_json = json.loads(raw)  # ← 계속 덮어써서 '가장 최신'만 유지
                    except json.JSONDecodeError:
                        continue
                if last_json is not None:
                    return last_json

        except OSError as e:
            print(f"[ERROR] receive() socket error: {e} -> reconnect and return None")
            self._reconnect()
            return None

    def close(self):
        try:
            if hasattr(self, 'client_socket'):
                try:
                    self.client_socket.shutdown(socket.SHUT_RDWR)
                except Exception:
                    pass
                self.client_socket.close()
        except Exception as e:
            print(f"[ERROR] client_socket close failed: {e}")
        try:
            if hasattr(self, 'server_socket'):
                self.server_socket.close()
        except Exception as e:
            print(f"[ERROR] server_socket close failed: {e}")
